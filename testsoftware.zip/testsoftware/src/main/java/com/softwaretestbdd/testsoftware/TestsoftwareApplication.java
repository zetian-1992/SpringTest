package com.softwaretestbdd.testsoftware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestsoftwareApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestsoftwareApplication.class, args);
	}

}
